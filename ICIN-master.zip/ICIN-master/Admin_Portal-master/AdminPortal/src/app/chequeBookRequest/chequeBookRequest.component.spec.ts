/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ChequeBookRequestComponent } from './chequeBookRequest.component';

describe('Component: ChequeBookRequest', () => {
  it('should create an instance', () => {
    let component = new ChequeBookRequestComponent();
    expect(component).toBeTruthy();
  });
});
