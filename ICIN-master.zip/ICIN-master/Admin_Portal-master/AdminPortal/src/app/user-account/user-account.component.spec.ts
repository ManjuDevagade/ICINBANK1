/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UserAccountComponent } from './user-account.component';

describe('Component: UserAccount', () => {
  it('should create an instance', () => {
   
  });
});
